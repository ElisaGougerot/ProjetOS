/**
 * \file file_head.c
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 *
 *
 */


File_head new_File_head(){ //create a new file head
	File_head fh; //variable's declaration

	strcpy(fh.file_type, "-"); //set the file type to -
	fh.access = 777; //set the access for everyone
	fh.links_number = 1; //set the link's number to 1
	fh.UID = 1;// user ID
	fh.GID = 1; // groupe ID
	fh.size = 2*BLOCK_SIZE_FOR_FILE; //set the size from de file head to 2 time the block's file size
	fh.address = 0;
	strcpy(fh.name, "fichier vide"); //set the name to empty file
	return fh; // return the file head
}

File_head get_File_head(int fd, Inode inode){ //get the file head from inode
	File_head fh;
	char text[SIZE_OF_FILE_HEAD+1]="";
	lseek(fd, inode, SEEK_SET); // put the file's cursor to the inode's address
	int access, links_number, UID, GID, size, adresse;// declare the variables

	if (read(fd, fh.file_type, SIZE_OF_FILE_TYPE) == -1) {    //initialization of the file's type
			printf("ERROR WRITE: %s\n", strerror(errno)); // if error print ...
  }
	bzero(text, sizeof(text));// replace every characters by \0

	if (read(fd, text, SIZE_OF_ACCESS) == -1) {  //initialization of the access typei
			printf("ERROR WRITE: %s\n", strerror(errno));// if error print ...
  }
	fh.access = atoi(text); //translate a string to integer
	bzero(text, sizeof(text));// replace every characters by \0


	if (read(fd, text, SIZE_OF_LINKS_NUMBER) == -1) {//initialization of the link's number
			printf("ERROR WRITE: %s\n", strerror(errno));// if error print ..
  }
	fh.links_number = atoi(text);
	bzero(text, sizeof(text));

	if (read(fd, text, SIZE_OF_UID) == -1) { //initialization of de user's number
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.UID = atoi(text);
	bzero(text, sizeof(text));

	if (read(fd, text, SIZE_OF_GID) == -1) { //initialization of the number of links
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.GID = atoi(text);
	bzero(text, sizeof(text));

	if (read(fd, text, SIZE_OF_FILE) == -1) { //initialization of the file's size
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.size = atoi(text);
	bzero(text, sizeof(text));

	if (read(fd, text, SIZE_OF_INODE) == -1) { //initialization of the address is size
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.address= atoi(text);
	bzero(text, sizeof(text));

	if (read(fd, fh.name, SIZE_OF_FILE_NAME) == -1) { //initialization of the file's name
			printf("ERROR WRITE: %s\n", strerror(errno));
	}
	bzero(text, sizeof(text));

	return fh; // return the file head
}

void file_head_to_str(File_head fh, char * str){  //convert file head to a string
	char info[SIZE_OF_FILE_HEAD+1];
	char cat[SIZE_OF_FILE_HEAD+1];
	strcpy(cat, "0");
	int sizeofinfo = 0;
	int index = 0;
	bzero(str, sizeof(str));

	sizeofinfo = sizeof(fh.file_type); //adding the file's type

	if (sizeofinfo<SIZE_OF_FILE_TYPE) {strcat(info, "-");}
	else{str = strncat(str, fh.file_type,1);}

	sizeofinfo = sprintf(info, "%d", fh.access); //adding the autorisation's access
	while (sizeofinfo<SIZE_OF_ACCESS) {
		sizeofinfo = sprintf(info, "0%s", info);
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	sizeofinfo = sprintf(info, "%d", fh.links_number); // adding the number of links
	while (sizeofinfo<SIZE_OF_LINKS_NUMBER) {
		strcat(cat, info);
		strcpy(info, cat);
		bzero(cat, sizeof(cat));
		strcpy(cat, "0");
		sizeofinfo++;
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	sizeofinfo = sprintf(info, "%d", fh.UID); //adding the user's ID
	while (sizeofinfo<SIZE_OF_UID) {
		strcat(cat, info);
		strcpy(info, cat);
		bzero(cat, sizeof(cat));
		strcpy(cat, "0");
		sizeofinfo++;
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	sizeofinfo = sprintf(info, "%d", fh.GID); // adding the group's ID
	while (sizeofinfo<SIZE_OF_GID) {
		strcat(cat, info);
		strcpy(info, cat);
		bzero(cat, sizeof(cat));
		strcpy(cat, "0");
		sizeofinfo++;
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	sizeofinfo = sprintf(info, "%d", fh.size); // adding the file's size
	while (sizeofinfo<SIZE_OF_FILE) {
		strcat(cat, info);
		strcpy(info, cat);
		bzero(cat, sizeof(cat));
		strcpy(cat, "0");
		sizeofinfo++;
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	sizeofinfo = sprintf(info, "%d", fh.address); // adding the inode
	while (sizeofinfo<SIZE_OF_INODE) {
		strcat(cat, info);
		strcpy(info, cat);
		bzero(cat, sizeof(cat));
		strcpy(cat, "0");
		sizeofinfo++;
	}
	strcat(str, info);
	bzero(info, sizeof(info));

	strcat(str, fh.name); // adding the file's name

}

File_head str_to_file_head(char *str){ // convert a string into a file head
	int index = 0;
	char info[32]="";
	File_head fh = new_File_head();
	char text[50];
	strcpy(text, str);

	strncat(info, str,SIZE_OF_FILE_TYPE);  //convert the file's type
	strcpy(fh.file_type, info);
	index = SIZE_OF_FILE_TYPE;
	bzero(info, sizeof(info));

	strncat(info, str+index,SIZE_OF_ACCESS);  //convert the autorisation's access
	fh.access = atoi(info);
	index+=SIZE_OF_ACCESS;
	bzero(info, sizeof(info));

	strncat(info, str+index,SIZE_OF_LINKS_NUMBER);  //convert the number of links
	fh.links_number = atoi(info);
	index+=SIZE_OF_LINKS_NUMBER;
	bzero(info, sizeof(info));

	strncat(info, str+index,SIZE_OF_UID);  //convert the user's ID
	fh.UID = atoi(info);
	index+=SIZE_OF_UID;
	bzero(info, sizeof(info));

	strncat(info, str+index,SIZE_OF_GID);  //convert the group's ID
	fh.GID = atoi(info);
	index+=SIZE_OF_GID;
	bzero(info, sizeof(info));


	strncat(info, str+index,SIZE_OF_FILE); //convert the file's size
	fh.size = atoi(info);
	index+=SIZE_OF_FILE;
	bzero(info, sizeof(info));

	strncat(info, str+index,SIZE_OF_INODE);  //convert the inode's size
	fh.address = atoi(info);
	index+=SIZE_OF_INODE;
	bzero(info, sizeof(info));

	strcpy(fh.name, str+index);

	 return fh;
}
void print_File_head(File_head fh){  // display the file head

	printf("type de fichier [%s]\nacces [%d]\nnombre de lien [%d]\nID utilisateur [%d]\nID groupe [%d]\ntaille du fichier [%d]\nInode [%d]\nname [%s]\n",
					 	fh.file_type,
						fh.access,
						fh.links_number,
						fh.UID,
						fh.GID,
						fh.size,
						fh.address,
						fh.name
				);
}
