

void printShell(char *msg){ //display a character in each line
  printf("%s\n>", msg);
}



int getMemoryMaxSize(int fd){ //get the max size memory
  char buff[100]="";
  char ch[2];
  lseek(fd, 0, SEEK_SET);
  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
    strcat(buff, ch);
    strcpy(ch, "");
  }
  return atoi(buff);
}

int getCurrentMemorySize(int fd){ //get the current memory's size
  char buff[100]="";
  char ch[2];
  lseek(fd, 0, SEEK_SET);
  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
  }

  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
    strcat(buff, ch);
    strcpy(ch, "");
  }
  return atoi(buff);
}

void affiche_memory(){ //display the memory
	char chr[2];
	int fd = open("memory.txt", O_CREAT|O_RDWR, 0666);
	while(read(fd, chr, 1) == 1){
		printf("%s", chr);
	}
  printf("\n");
}

void write_in_file(int fd, Inode inode, char *text, int size_text){ //write in a file
  File_head fh;
  char text_file_head[SIZE_OF_FILE_HEAD];
  char info[BLOCK_SIZE_FOR_FILE];
  char new[BLOCK_SIZE_FOR_FILE];
  char cat[SIZE_OF_FILE_HEAD+1]="0";
  Inode new_inode;
  int sizeofinfo;

  read_f(fd, inode, SIZE_OF_FILE_HEAD, text_file_head);
  fh = str_to_file_head(text_file_head);
  fh.size = sizeof(text);

  clean_file(fd, fh.address);
  int i = 0;

  for (i = 0; i < (size_text/BLOCK_SIZE_FOR_FILE); i++) {
      new_inode = find_available_block(fd, INDEX_OF_INODE_TABLE);

      write_f(fd, new_inode, BLOCK_SIZE_FOR_FILE, text+(i*BLOCK_SIZE_FOR_FILE));
      sizeofinfo = sprintf(info, "%d", new_inode);
      while (sizeofinfo<SIZE_OF_INODE) {
        strcat(cat, info);
        strcpy(info, cat);
        bzero(cat, sizeof(cat));
        strcpy(cat, "0");
        sizeofinfo++;
      }
      strncpy(new, info, SIZE_OF_INODE);
  }
  new_inode = find_available_block(fd, INDEX_OF_INODE_TABLE);

  write_f(fd, new_inode, size_text-(i*BLOCK_SIZE_FOR_FILE), text+(i*BLOCK_SIZE_FOR_FILE));
  read_f(fd, new_inode, size_text-(i*BLOCK_SIZE_FOR_FILE), info);


  sizeofinfo = sprintf(info, "%d", new_inode);
  while (sizeofinfo<SIZE_OF_INODE) {
    strcat(cat, info);
    strcpy(info, cat);
    bzero(cat, sizeof(cat));
    strcpy(cat, "0");
    sizeofinfo++;
  }
  strncpy(new, info, SIZE_OF_INODE);

  write_f(fd, fh.address, BLOCK_SIZE_FOR_FILE, new);
  write_f(fd, new_inode, size_text-(i*BLOCK_SIZE_FOR_FILE), text+(i*BLOCK_SIZE_FOR_FILE));
  read_f(fd, new_inode, size_text-(i*BLOCK_SIZE_FOR_FILE), new);

}

void ls_f(int fd, Inode inode, char *value){ //display every file and folder in the current folder or emplacement
  File_head fh;
  File_head fh2;
  char text[BLOCK_SIZE_FOR_FILE];
  char str_tmp[SIZE_OF_INODE];
  char name[SIZE_OF_FILE_HEAD];
  char names[BLOCK_SIZE_FOR_FILE];
  int index = SIZE_OF_INODE*2;
  Inode tmp;

  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  fh = str_to_file_head(text);
  read_f(fd, fh.address, BLOCK_SIZE_FOR_FILE, text);
  bzero(names, sizeof(names));
  //we get information from every inode
  for (size_t i = 0; i < (fh.size/BLOCK_SIZE_FOR_FILE); i++) {
    bzero(str_tmp, sizeof(str_tmp));
    strncat(str_tmp, text+(i*SIZE_OF_INODE), SIZE_OF_INODE);
    tmp = atoi(str_tmp);

    read_f(fd, tmp, SIZE_OF_FILE_HEAD, name);
    fh2 = str_to_file_head(name);
    if (i==0) {
      strncat(names, "..", 2);
    }
    else if (i==1){
      strncat(names, ".", 1);
    }
    else{
        strncat(names, fh2.name, SIZE_OF_FILE_NAME);
    }


    strcat(names, "\t");
  }
  bzero(value, sizeof(value));
  strcat(value, names);



}

void rename_f(int fd, Inode inode, char *new_name){//rename a file or a folder
  File_head fh;
  char text[SIZE_OF_FILE_HEAD];

  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  fh = str_to_file_head(text);


  bzero(fh.name, SIZE_OF_FILE_NAME);
  strncpy(fh.name, new_name, SIZE_OF_FILE_NAME);

  bzero(text, sizeof(text));
  file_head_to_str(fh, text);

  write_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);



}

Inode get_inode_from_name(int fd, Inode inode, char *filename){
  char current_name[SIZE_OF_FILE_NAME];
  char names[BLOCK_SIZE_FOR_FILE];
  char text[BLOCK_SIZE_FOR_FILE];
  char chr[2]="";
  int index = 0;
  int name_index = 0;
  int where =-1;
  File_head fh;

  ls_f(fd, inode, names);
  strncpy(chr, names, 1);
  bzero(current_name, sizeof(current_name));

  while (strcmp(chr, "\0")!=0) {
    strncpy(chr, names+index, 1);
    if (strcmp(chr, "\t")==0) {

      if (strcmp(current_name, filename)==0) {
        where = name_index;
      }

      bzero(current_name, sizeof(current_name));
      name_index++;
    }
    else{
      strncat(current_name, chr, 1);
    }

    index++;
  }

  if (where == -1) {
    printf("No such file or directory\n");
    return -1;
  }
  else{

    read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
    fh = str_to_file_head(text);

    bzero(text, sizeof(text));
    read_f(fd, fh.address, BLOCK_SIZE_FOR_FILE, text);

    bzero(text, sizeof(text));

    read_f(fd, fh.address + (where*SIZE_OF_INODE), SIZE_OF_INODE, text);
    return atoi(text);

  }

}

void cp_f(int fd, Inode inode, char *filename, char *new_filename) { //copy and print a file into a new file's name
  Inode inode_file_to_copy = get_inode_from_name(fd, inode, filename);
  File_head fh, new_fh, parent_fh;
  char text[BLOCK_SIZE_FOR_FILE];
  char info[SIZE_OF_INODE];
  char cat[SIZE_OF_FILE_HEAD+1];
  strcpy(cat, "0");
  bzero(text, sizeof(text));

  if (inode_file_to_copy == -1) {
    return;
  }
  Inode new_file_inode = find_available_block(fd, INDEX_OF_INODE_TABLE);
  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  parent_fh = str_to_file_head(text);
  parent_fh.size += BLOCK_SIZE_FOR_FILE;
  file_head_to_str(parent_fh, text);
  write_f(fd, inode, SIZE_OF_FILE_HEAD, text);


  read_f(fd, inode_file_to_copy, SIZE_OF_FILE_HEAD, text);
  fh = str_to_file_head(text);
  new_fh = fh;
  strncpy(new_fh.name, new_filename, SIZE_OF_FILE_NAME);


  bzero(text, sizeof(text));
  read_f(fd, parent_fh.address, BLOCK_SIZE_FOR_FILE, text);

  int sizeofinfo = sprintf(info, "%d", new_file_inode);
  while (sizeofinfo<SIZE_OF_INODE) {
    strcat(cat, info);
    strcpy(info, cat);
    bzero(cat, sizeof(cat));
    strcpy(cat, "0");
    sizeofinfo++;
  }

  strncat(text, info, SIZE_OF_INODE);
  write_f(fd, parent_fh.address, BLOCK_SIZE_FOR_FILE, text);


  file_head_to_str(new_fh, text);

  write_f(fd, new_file_inode, SIZE_OF_FILE_HEAD, text);




}

void rm_f(int fd, Inode inode, char *filename){ //remove a file or a folder who already exists
  Inode inode_file_delete = get_inode_from_name(fd, inode, filename);
  Inode tmp_inode;
  char text[BLOCK_SIZE_FOR_FILE];
  char str_inode[SIZE_OF_INODE];
  char new_list[BLOCK_SIZE_FOR_FILE];
  char chr[2];
  File_head fh, del;
  if (inode_file_delete == -1) {
    return;
  }
  bzero(new_list, sizeof(new_list));
  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  fh = str_to_file_head(text);
  bzero(text, sizeof(text));
  read_f(fd, fh.address, SIZE_OF_INODE*(fh.size/BLOCK_SIZE_FOR_FILE), text);


  for (size_t i = 0; i < fh.size/BLOCK_SIZE_FOR_FILE; i++) {
    bzero(str_inode, sizeof(str_inode));
    strncat(str_inode, text+(i*SIZE_OF_INODE), SIZE_OF_INODE);
    tmp_inode = atoi(str_inode);
    if (tmp_inode != inode_file_delete) {
      strncat(new_list, str_inode, SIZE_OF_INODE);
    }
    else{
    }

  }

  fh.size -=BLOCK_SIZE_FOR_FILE;

  write_f(fd, fh.address, SIZE_OF_INODE*(fh.size/BLOCK_SIZE_FOR_FILE), new_list);
  read_f(fd, fh.address, SIZE_OF_INODE*(fh.size/BLOCK_SIZE_FOR_FILE), text);

  file_head_to_str(fh, text);
  write_f(fd, inode, SIZE_OF_FILE_HEAD, text);



}

Inode cd_f(int fd, Inode inode, char *dirname){
  Inode dir_inode = get_inode_from_name(fd, inode, dirname);
  char text[SIZE_OF_FILE_HEAD];
  File_head fh;
  if (dir_inode==-1) {
    return -1;
  }
  read_f(fd, inode, SIZE_OF_FILE_HEAD, text);
  fh = str_to_file_head(text);
  if (strcmp(fh.file_type, "d")!=0) {
    printf("%s In sot a directory\n", fh.name);
    return -2;
  }
  return dir_inode;

}

void getCmd(int fd, Inode inode) {


  int quit=0;
  char cmd[30]="";
  char filename[SIZE_OF_FILE_NAME];
  char filename2[SIZE_OF_FILE_NAME];
  char ls[BLOCK_SIZE_FOR_FILE];
  Inode tmp_inode;
  while (quit!=1) {
    scanf("%s", cmd);
    if (strcmp(cmd, "")==0) {
      printf("rien :[%s]\n", cmd);
    }
    else if (strcmp(cmd, "help")==0) {
      printf("<q> : to quite\n<cp> : to copy\n<ls> for directory content\n<create> to create a file or a diractory\n<cd> to change the current directory\n<rename> to rename a file or a directory\n<rm> to delete a file or a directory\n");
    }
    else if (strcmp(cmd, "q")==0) {
      quit=1;
    }
    else if(strcmp(cmd, "cp")==0){
      printf("Type file name\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s", filename);
      printf("Type new file name\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s",filename2);
      cp_f(fd, inode, filename, filename2);
    }
    else if (strcmp(cmd, "ls")==0){
      ls_f(fd, inode, ls);
      printf("%s\n", ls);
      bzero(ls, sizeof(ls));
    }
    else if (strcmp(cmd, "create")==0){
      printf("Type file name\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s", filename);
      printf("Type file type (f or d)\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s\n",filename2);
      create_file(fd, filename, inode, 0, INDEX_OF_INODE_TABLE, filename2);
    }
    else if(strcmp(cmd, "rename")==0){
      printf("Type file name\n");
      scanf("%s", cmd);
      printf("Type new file name\n");
      sscanf(cmd, "%s", filename);
      scanf("%s", cmd);
      sscanf(cmd, "%s",filename2);
      Inode inode2 = get_inode_from_name(fd, inode, filename);
      rename_f(fd, inode2, filename2);
    }
    else if(strcmp(cmd, "cd")==0){
      printf("Type directory name\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s", filename);
      tmp_inode = cd_f(fd,inode, filename);
      if (tmp_inode>0) {
        inode = tmp_inode;
      }
    }
    else if(strcmp(cmd, "rm")==0){
      printf("Type the name\n");
      scanf("%s", cmd);
      sscanf(cmd, "%s", filename);
      rm_f(fd, inode, filename);
    }
    else{
      printf("Wrong command type help\n");
    }
    strcpy(cmd, "");
  }
}
