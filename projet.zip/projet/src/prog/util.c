

void printShell(char *msg){
  printf("%s\n>", msg);
}

void getCmd(void) {
  int quit=0;
  char cmd[30]="";
  while (quit!=1) {
    scanf("%s", cmd);
    if (strcmp(cmd, "")==0) {
      printf("rien :[%s]\n", cmd);
      printShell("");
    }
    else if (strcmp(cmd, "help")==0) {
      printShell("command help");
    }
    else if (strcmp(cmd, "q")==0) {
      quit=1;
    }
    else{
      printShell("invalid cmd type help for help");
    }
    strcpy(cmd, "");
  }
}

int getMemoryMaxSize(int fd){
  char buff[100]="";
  char ch[2];
  lseek(fd, 0, SEEK_SET);
  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
    strcat(buff, ch);
    strcpy(ch, "");
  }
  return atoi(buff);
}

int getCurrentMemorySize(int fd){
  char buff[100]="";
  char ch[2];
  lseek(fd, 0, SEEK_SET);
  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
  }

  while ((read(fd, ch, 1) == 1) && (strcmp(ch, "\n")!=0)) {
    strcat(buff, ch);
    strcpy(ch, "");
  }
  return atoi(buff);
}

void affiche_memory(){
	char chr[2];
	int fd = open("memory.txt", O_CREAT|O_RDWR, 0666);
	while(read(fd, chr, 1) == 1){
		printf("%s", chr);
	}
  printf("\n");
}
