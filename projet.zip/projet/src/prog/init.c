

int new_memory(int fd) {
 char str[200] ="";
  int size_str = sprintf(str, "%s\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",
                                                                              FILE_SYSTEM_NAME,
                                                                              MAX_MEMORY_SIZE,
                                                                              BLOCK_SIZE_FOR_FILE,
                                                                              SIZE_OF_INODE,
                                                                              SIZE_OF_INODE_TABLE,
                                                                              SIZE_OF_FILE_HEAD,
                                                                              SIZE_OF_ACCESS,
                                                                              SIZE_OF_LINKS_NUMBER,
                                                                              SIZE_OF_UID,
                                                                              SIZE_OF_GID,
                                                                              SIZE_OF_FILE
                                                                            );

  char buff[size_str+1];
  strcpy(buff, str);
  strcat(buff, "\n");

  if (write(fd, buff, sizeof(buff)) == -1) {
    printf("ERROR WRITE: %s\n", strerror(errno));
  }
  return fd;
}

int init_Memory_Systeme(int fd, char *buff){
  if (write(fd, buff, sizeof(buff)) == -1) {
    printf("ERROR WRITE: %s\n", strerror(errno));
  }
}

int new_File_head(File_head fh, int adress_of_){

}

Address_List init_Address_List(){
  Address_List al;
  al.address[0] = 1;
	int i=0;
  for (i = 1; i < SIZE_OF_INODE_TABLE; i++) {
    al.address[i] = 0;
  }
  return al;
}

int init_Address_Table(int fd, int curpos){
	Address_List al;
	int i=0;
  printf("start\n");

	al.address[0] = 1;
		if (write(fd, "1", 1) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  		}
	for(i=1; i<SIZE_OF_INODE_TABLE-1; i++){
		al.address[i] = 0;
		curpos++;
		if (write(fd, "0", 1) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  		}
	}
	return curpos;

}
