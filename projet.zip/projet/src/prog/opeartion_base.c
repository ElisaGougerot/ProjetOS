int write_f(int fd, int inode, char *buff ){
  
}
