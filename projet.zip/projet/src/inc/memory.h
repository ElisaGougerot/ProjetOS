/**
 * \file memory.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 *
 *
 */

#include "../prog/memory.c"

/**
 * \struct init_Address_List
 * \brief Initialize the address list
 *
 *
 */
Address_List init_Address_List();

/**
 * \struct find_available_block
 * \brief Find an available block
 * \return the position of the available block
 * \param file descriptor and the place to look
 */
Inode find_available_block(int fd, int cursor);

/**
 * \struct free_block
 * \brief 
 * \return a new memory (with an integer)
 * \param address list, the inode of the address list and the inode
 */
void free_block(Address_List al, Inode inode_al, Inode inode);

/**
 * \struct write_f
 * \brief write in the file
 * \return text
 * \param file descriptor, the inode, the size and the text
 */
void write_f(int fd, Inode inode, int size, char *text);

/**
 * \struct read_f
 * \brief Read inside the document
 * \return text
 * \param file descriptor, inode, the size and the text
 */
void read_f( int fd, Inode inode, int size, char *text);
