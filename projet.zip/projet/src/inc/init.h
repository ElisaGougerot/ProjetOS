/**
 * \file constants.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 * Fonction's Protype
 *
 */

#include "constants.h"
#include "struct.h"
#include "file_head.h"
#include "../prog/init.c"
#include "memory.h"
#include "util.h"

/**
 * \struct new_memory
 * \brief Creat a new memory
 * \return a new memory (with an integer)
 * \param file descriptor
 */
int new_memory(int fd);

/**
 * \struct init_Memory_Systeme
 * \brief initialize the new memory
 *
 * \param file descriptor and a string of characters
 */
int init_Memory_Systeme(int fd, char *buff);

/**
 * \struct open_Memory
 * \brief Open the memory
 *
 * \param Name of the file
 */
int open_Memory(char *filename);

/**
 * \struct init_Address_Table
 * \brief Initialize the address table
 * 
 * \param file descriptor
 */
void init_Address_Table(int fd);
