
#include "../prog/init.c"
#include "../prog/opeartion_base.c"
int new_memory(int fd);

int init_Memory_Systeme(int fd, char *buff);

int new_File_head(File_head inode, int adress_of_);

int init_Address_Table(int fd, int poscurs);
