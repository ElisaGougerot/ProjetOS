#include "constants.h"
#include "struct.h"

#include "util.h"
#include "file_head.h"
#include "memory.h"
#include "../prog/init.c"
int new_memory(int fd);

int init_Memory_Systeme(int fd, char *buff);

int open_Memory(char *filename);

void init_Address_Table(int fd);
