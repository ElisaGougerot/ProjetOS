/**
 * \file constants.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 *
 *
 */


#include "../prog/util.c"

/**
 * \struct printShell
 * \brief Character of display
 *
 * \param character msg
 */
void printShell(char *msg);

/**
 * \struct getCmd
 * \brief recover the order
 *
 * \param character msg
 */
void getCmd(void);

/**
 * \struct getMemoryMaxSize
 * \brief gt the maximal size of the memory
 *
 * \param file director
 * \return the maximal size
 */
int getMemoryMaxSize(int fd);

/**
 * \struct getCurrentMemorySize
 * \brief get the current size of the memory
 *
 * \param file director
 * \return the current size
 */
int getCurrentMemorySize(int fd);

/**
 * \struct affiche_memory
 * \brief display the memory
 *
 *
 */
void affiche_memory();
