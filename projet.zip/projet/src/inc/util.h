#include "../prog/util.c"


void printShell(char *msg);
void getCmd(void);
int getMemoryMaxSize(int fd);
int getCurrentMemorySize(int fd);
void affiche_memory();
