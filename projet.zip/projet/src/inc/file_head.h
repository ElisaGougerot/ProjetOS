/**
 * \file constants.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 * Definition of the macros in our file system
 *
 */

#include "../prog/file_head.c"

/**
 * \struct new_File_head
 * \brief Creat a new file head
 * \return file head
 *
 */
File_head new_File_head();

/**
 * \struct str_to_file_head
 * \brief Convert a string into a file head
 * \return a file head
 * \param pointer into a string
 */
File_head str_to_file_head(char *str);

/**
 * \struct print_File_head
 * \brief Return the file head
 * \param file head
 */
void print_File_head(File_head fh);

/**
 * \struct get_File_head
 * \brief Recoverd the file head
 * \return file head
 * \param file descriptor and a inode
 */
File_head get_File_head(int fd, Inode inode);
