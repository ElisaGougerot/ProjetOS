/**
 * \file constants.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 * Definition of the macros in our file system
 *
 */
//JP 70% R 15% E 15%

#ifndef CONSTANTS
#define CONSTANTS

#define FILE_SYSTEM_NAME "--FILE SYSTEME--\n"

/**
 * \struct Memory
 * \brief Different constants for the memory
 *
 */

#define MAX_MEMORY_SIZE 1048576 //Maximal size of the memory
/**
 *
 * \brief Total size of the memory
 *
 */
#define BLOCK_SIZE_FOR_FILE 1024 //Size of a file's block
/**
 *
 * \brief Size of a block
 *
 */
#define SIZE_OF_INODE 6//Size of the inode
/**
 *
 * \brief Number of characters to write an inode
 *
 */
#define SIZE_OF_INODE_TABLE 128//Size of the inode's table
/**
 *
 * \brief Number of inodes in the table of inodes
 *
 */
#define INDEX_OF_INODE_TABLE 50//First character of the inode's table


/**
 * \struct Macros
 * \brief Different macros for a file head
 *
 */

#define SIZE_OF_FILE_TYPE 1 //Size of the file's type
#define SIZE_OF_ACCESS 3 //Size of the access rigths
#define SIZE_OF_LINKS_NUMBER 2 //Number of links
#define SIZE_OF_UID 3 //characters is number for the access rights for the user
#define SIZE_OF_GID 3//characters is number for the access rights for the group
#define SIZE_OF_FILE 7 //Size of a file
#define SIZE_OF_FILE_NAME 30 //Maximal size of a name's file
#define SIZE_OF_FILE_HEAD SIZE_OF_FILE_TYPE + SIZE_OF_ACCESS + SIZE_OF_LINKS_NUMBER + SIZE_OF_UID + SIZE_OF_GID + SIZE_OF_FILE + SIZE_OF_INODE + SIZE_OF_FILE_NAME

#endif
