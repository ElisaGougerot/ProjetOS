/**
 * \file struct.h
 * \author Jean-Philippe, Elisa, Raphaël
 * \version 0.1
 * \date 29 mars 2019
 *
 *  every structures of the project
 *
 */

//JP 50% R 25% E 25%
/**
 * \struct int Inode
 * \brief The inode is just an address in the memory
 *
 */
typedef int Inode;

/**
 * \struct File_head
 * \brief Dtructure definition of a file head
 *
 *
 */
typedef struct{
  char file_type[1];
  int access;
  int links_number;
  int UID;//ID de l'utilisateur Pour vérifier qu'il à le droit de consulter le fichier
  int GID;//même chose mais pour le groupe
  int size;
  char name[SIZE_OF_FILE_NAME];
  Inode address;//adresse du block mémoire
}File_head;

/**
 * \struct File
 * \brief Structure definition of a file
 *
 *
 */
typedef struct{
  Inode inode;
  int size;
}File;

/**
 * \struct Address_list
 * \brief Structure definition of an address list
 *
 *
 */
typedef struct {
 char address[SIZE_OF_INODE_TABLE];
}Address_List;

/**
 * \struct Data_Block_List
 * \brief structure definition of data block list
 *
 *
 */
typedef struct{
  Inode *inode;
}Data_Block_List;
