


File_head get_File_head(int fd, Inode inode){
	File_head fh;
	char text[SIZE_OF_FILE_HEAD+1]="";
	lseek(fd, inode, SEEK_SET);
	int access, links_number, UID, GID, size, adresse;

    //initialisation  du type de fichier
	if (read(fd, fh.file_type, SIZE_OF_FILE_TYPE) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	bzero(text, sizeof(text));

  //initialisation  du type d'acces
	if (read(fd, text, SIZE_OF_ACCESS) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.access = atoi(text);
	bzero(text, sizeof(text));

  //initialisation  du nombre de lien
	if (read(fd, text, SIZE_OF_LINKS_NUMBER) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.links_number = atoi(text);
	bzero(text, sizeof(text));

  //initialisation  du numero utilisateur
	if (read(fd, text, SIZE_OF_UID) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.UID = atoi(text);
	bzero(text, sizeof(text));

  //initialisation  du nombre de lien
	if (read(fd, text, SIZE_OF_GID) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.GID = atoi(text);
	bzero(text, sizeof(text));

  //initialisation  de la taille du fichier
	if (read(fd, text, SIZE_OF_FILE) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh. = atoi(text);
	bzero(text, sizeof(text));

  //initialisation  de la taille de l'adresse
	if (read(fd, text, SIZE_OF_ADDRESS) == -1) {
			printf("ERROR WRITE: %s\n", strerror(errno));
  }
	fh.= atoi(text);
	bzero(text, sizeof(text));
}
