
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>

////////////////
#include "src/inc/init.h"

//////////////


int main(int argc, char const *argv[]) {
  char text[SIZE_OF_INODE_TABLE+1];
  char test[SIZE_OF_FILE_HEAD];
  char value[BLOCK_SIZE_FOR_FILE];
  Inode current_folder_inode;


  char input[100]="", scn[100]="";
  printf("\t\tFILE MANAGER\n\tby pauquet jean-philippe\n>");


  int fd = open_Memory("");
  Inode current = find_available_block(fd, INDEX_OF_INODE_TABLE);
  create_file(fd, ".", current, 1, INDEX_OF_INODE_TABLE, "d");
  getCmd(fd, current);



//
// int fd = open_Memory("");
// char text[SIZE_OF_INODE_TABLE+1];
// char test[SIZE_OF_FILE_HEAD];
// char value[BLOCK_SIZE_FOR_FILE];
// int cursor = new_memory(fd);
// int cursor_address_table = cursor;
// Inode current_folder_inode;
//
// Inode current = find_available_block(fd, cursor_address_table);
//
//
// create_file(fd, ".", current, 1, cursor_address_table, "d");
//
// create_file(fd, "file.txt", current, 0, cursor_address_table, "f");
// create_file(fd, "text.pdf", current, 0, cursor_address_table, "f");
// create_file(fd, "dossier", current, 0, cursor_address_table, "d");
// char pk[30] = "YEEEEEEEES YESSSSS !";
// write_in_file(fd, 3072, pk, sizeof(pk));
//
// cp_f(fd, current, "file.txt", "new_file.txt");
//
// ls_f(fd, current, text);
// printf("[%s]LS\n", text);
//
//
// ls_f(fd, current, text);
// printf("[%s]LS\n", text);
  return 0;
}
