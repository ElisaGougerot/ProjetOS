//
//#include "src/opeartion_base.c"
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>

////////////////
#include "src/inc/constants.h"
#include "src/inc/struct.h"
#include "src/inc/init.h"
#include "src/inc/util.h"

//////////////


int main(int argc, char const *argv[]) {
  // char input[100]="", scn[100]="";
  // printf("\t\tFILE MANAGER\n\tby pauquet jean-philippe\n>");
  // for (size_t i = 0; sizeof("100")+i < 8; i++) {
  //   printf("|");
  // }
  // printf("%s", "100\n");
  // int val = 100 - 16;
  // char str[7]="";
  // sprintf(str, "%d", val);
  // for (size_t i = 0; sizeof(str)+i < 8; i++) {
  //   printf("|");
  // }
  // printf("%s\n", str);
  // /*
  // int fd = new_memory(30);
  // getMemoryMaxSize(fd);
  // getCurrentMemorySize(fd);
  // getCmd();
  // */
int fd = open("memory.txt", O_CREAT|O_RDWR, 0666);
int curpos = new_memory(fd);
affiche_memory();
int cur = init_Address_Table(fd, curpos);
affiche_memory();



  return 0;
}
