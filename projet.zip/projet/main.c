
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>

////////////////
#include "src/inc/init.h"

//////////////
//JP 100%



int main(int argc, char const *argv[]) {
  char text[SIZE_OF_INODE_TABLE+1];
  char test[SIZE_OF_FILE_HEAD];
  char value[BLOCK_SIZE_FOR_FILE];
  Inode current_folder_inode;


  char input[100]="", scn[100]="";
  int go = 0, fd;
  char cmd[30]="";

  printf("\t\tFILE MANAGER\n\tby Jean-Philippe, Elisa, Raphael\n");

  while (go!=1) {
    printf("Type new or continue\n");
    scanf("%s", cmd);
    if(strcmp(cmd, "new")==0){
       fd = open_Memory("");
       new_memory(fd);
       Inode current = find_available_block(fd, INDEX_OF_INODE_TABLE);
       create_file(fd, ".", current, 1, INDEX_OF_INODE_TABLE, "d");
       go=1;
    }
    else if(strcmp(cmd, "continue")==0){
      fd = open_Memory("");
      go=1;
    }
  }
printf("WELLCOME\n");

  getCmd(fd, 1024);

  return 0;
}
